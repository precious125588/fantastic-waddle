#!/usr/bin/env node
/* ═══════════════════════════════════════════════════════════════════════════
   MAIS MDX — v26 HOTFIX  (runs automatically on every start, before server.js)

   Fixes the exact failures seen in the Railway deploy logs:

   1. TELEGRAM 409 CONFLICT WAR (the endless red wall in the logs)
      bot.js used to stopPolling() + deleteWebHook() + startPolling() on every
      409 AND reset its conflict counter to 0 after each "reclaim". With two
      containers polling the same token (old deployment + new deployment),
      each reclaim kicked the other one off → infinite reclaim war, forever.
      v26: count cumulatively, NEVER churn the poller, never reset. The
      node-telegram-bot-api library keeps retrying getUpdates by itself; the
      moment the old container dies, the next poll succeeds with zero churn.

   2. TIKTOK COMMAND DIES SILENTLY (no card, no reply, nothing)
      mias/index.js: `await forceReaction(sock, msg, "🌀")` was UNGUARDED at
      the top of the .tiktok/.tt handler. If the reaction threw (WA socket in
      405 conflict / Bad MAC state), the ENTIRE handler aborted before sending
      anything → user sees literally nothing. v26 wraps it in try/catch.
      Also: if the image-card send fails, fall back to the plain-text menu so
      the user ALWAYS gets an answer.
      Also: boot log now prints which handler owns .tiktok/.tt/.ttdl.

   3. BAD MAC REPAIR NEVER RAN
      The app-state-sync-* cleanup lived in start.sh, but Railway starts with
      `npm start` (server.js directly), so start.sh never executed and stale
      Signal session snapshots kept throwing "Bad MAC" on every reconnect.
      v26 does the cleanup here, at every boot.

   This file is IDEMPOTENT — safe to run on every start.
   ═══════════════════════════════════════════════════════════════════════════ */
"use strict";
const fs = require("fs");
const path = require("path");
const ROOT = __dirname;

const applied = [];
const skipped = [];
const failed = [];

function patchFile(rel, edits, { marker } = {}) {
  const abs = path.join(ROOT, rel);
  try {
    if (!fs.existsSync(abs)) { skipped.push(rel + " (file missing)"); return; }
    let src = fs.readFileSync(abs, "utf8");
    if (marker && src.includes(marker)) { skipped.push(rel + " (already patched)"); return; }
    let changed = false;
    for (const e of edits) {
      if (e.regex) {
        if (e.from.test(src)) { src = src.replace(e.from, e.to); changed = true; }
        else if (!e.optional) { failed.push(rel + " :: pattern not found: " + e.name); }
      } else {
        if (src.includes(e.from)) {
          src = e.all ? src.split(e.from).join(e.to) : src.replace(e.from, e.to);
          changed = true;
        } else if (!e.optional) { failed.push(rel + " :: text not found: " + e.name); }
      }
    }
    if (changed) { fs.writeFileSync(abs, src); applied.push(rel); }
    else skipped.push(rel + " (nothing to do)");
  } catch (err) {
    failed.push(rel + " :: " + err.message);
  }
}

/* ── 1) bot.js — stop the Telegram 409 reclaim war ────────────────────────── */
patchFile("bot.js", [
  {
    name: "409-handler",
    regex: true,
    from: /  if \(msg\.includes\('409'\) \|\| msg\.includes\('terminated by other getUpdates'\)\) \{[\s\S]*?\}, 15000\);\n    return;\n  \}/,
    to: `  if (msg.includes('409') || msg.includes('terminated by other getUpdates')) {
    // v26: another container still holds this token (old Railway deployment
    // that was never stopped). DO NOT stop/start the poller and DO NOT reset
    // the counter — that is what created the infinite reclaim war in the logs.
    // The library keeps retrying getUpdates on its own; when the old container
    // finally dies, the very next poll succeeds with zero churn.
    _tg409Count++;
    if (_tg409Count === 1 || _tg409Count % 30 === 0) {
      console.warn(chalk.yellow('⚠️  [Telegram] 409 Conflict x' + _tg409Count + ' — another instance is polling this token.'));
      console.warn(chalk.yellow('    Waiting it out. If this never stops, DELETE the old Railway service/deployment.'));
    }
    if (_tg409Count > 200) {
      console.error(chalk.red('❌ [Telegram] 409 conflict persisted — standing down. Run ONE instance only.'));
      try { bot.stopPolling(); } catch {}
      if (global._telegramBotState) global._telegramBotState.polling = false;
    }
    return;
  }`,
  },
], { marker: "v26: another container still holds this token" });

/* ── 2) mias/index.js — never let the TikTok handler die silently ─────────── */
patchFile(path.join("mias", "index.js"), [
  {
    name: "guard-forceReaction",
    from: `    await forceReaction(sock, msg, "🌀");`,
    to: `    try { await forceReaction(sock, msg, "🌀"); } catch (_frErr) { console.warn("[v26] reaction failed (socket busy) — continuing:", _frErr?.message || _frErr); }`,
    all: true,
  },
  {
    name: "image-card-fallback",
    from: `          if (thumb) {
            await sock.sendMessage(jid, { image: thumb, caption: menuCaption }, { quoted: msg });
          } else {
            await sendReply(sock, msg, menuCaption);
          }`,
    to: `          if (thumb) {
            try {
              await sock.sendMessage(jid, { image: thumb, caption: menuCaption }, { quoted: msg });
            } catch (_imgErr) {
              console.warn("[v26] TT image card failed, falling back to text menu:", _imgErr?.message || _imgErr);
              try { await sendReply(sock, msg, menuCaption); } catch {}
            }
          } else {
            await sendReply(sock, msg, menuCaption);
          }`,
  },
  {
    name: "boot-log-tt-handler",
    from: `for (const _ttn of ["tiktok", "tt", "ttdl"]) { const _te = commands.get(_ttn); if (_te) { _te.__ttCard = true; _te.__ttCardHandler = _te.handler; } }`,
    to: `for (const _ttn of ["tiktok", "tt", "ttdl"]) { const _te = commands.get(_ttn); if (_te) { _te.__ttCard = true; _te.__ttCardHandler = _te.handler; } }
console.log("[v26] tt handler bound:", ["tiktok","tt","ttdl"].map(n => n + "=" + (commands.get(n) ? "ok" : "MISSING")).join(" "));`,
  },
]);

/* ── 3) Bad MAC repair (moved out of start.sh, which npm start never calls) ── */
try {
  if (process.env.KEEP_BAD_MAC !== "1") {
    const candidates = [
      process.env.SESSION_DIR,
      "/app/nexstore/pairing",
      path.join(ROOT, "prezzy_auth"),
      path.join(ROOT, "pairing"),
    ].filter(Boolean);
    let cleared = 0;
    for (const base of candidates) {
      if (!fs.existsSync(base)) continue;
      const dirs = [base];
      try {
        for (const d of fs.readdirSync(base, { withFileTypes: true }))
          if (d.isDirectory()) dirs.push(path.join(base, d.name));
      } catch { continue; }
      for (const dir of dirs) {
        let entries = [];
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
        for (const e of entries) {
          if (e.isDirectory() && e.name.startsWith("app-state-sync-")) {
            try { fs.rmSync(path.join(dir, e.name), { recursive: true, force: true }); cleared++; } catch {}
          }
        }
      }
    }
    console.log(`[v26] Bad-MAC repair: cleared ${cleared} stale app-state-sync-* snapshot(s)`);
  }
} catch (e) {
  console.warn("[v26] Bad-MAC repair skipped:", e.message);
}

/* ── report ────────────────────────────────────────────────────────────────── */
for (const a of applied) console.log("[v26] PATCHED   " + a);
for (const s of skipped) console.log("[v26] skipped   " + s);
for (const f of failed)  console.warn("[v26] FAILED    " + f);
console.log("[v26] hotfix pass complete");
