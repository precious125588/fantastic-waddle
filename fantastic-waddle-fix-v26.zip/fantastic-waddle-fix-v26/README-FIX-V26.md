# MAIS MDX — v26 Fix Pack (Telegram 409 war + TikTok silent failure)

## What was actually wrong (root causes, from your repo + your logs)

1. **Telegram `409 Conflict` infinite loop** — `bot.js` reacted to every 409 by
   stopping polling, deleting the webhook and starting polling again, **and it
   reset its own conflict counter after each "reclaim"**. With TWO Railway
   containers polling the same bot token (your old deployment is still
   running — you said so yourself: *"the old one still there"*), each reclaim
   kicked the other container off → infinite reclaim war. That is the entire
   red wall in your deploy logs.

2. **TikTok command replied with NOTHING (not even the image card)** —
   `mias/index.js` runs `await forceReaction(sock, msg, "🌀")` **unguarded**
   at the very top of the `.tiktok / .tt` handler. While the WhatsApp socket
   is in its 405-conflict / Bad-MAC state (also caused by the duplicate
   container), that reaction throws and the **whole handler aborts before
   sending anything**. On top of that, `fetchTikTokInfo()` only had two
   tikwm.com endpoints; when tikwm rate-limits Railway's shared IPs, the card
   build failed too.

3. **Bad MAC repair never ran** — the cleanup lived in `start.sh`, but your
   Railway service starts with `npm start` → `server.js` directly, so
   `start.sh` (and its app-state-sync cleanup) never executed.

## Files in this pack

| File | Where it goes | What it does |
|---|---|---|
| `fix_v26.cjs` | repo root (next to `server.js`) | Runs on every `npm start`, BEFORE `server.js`. Patches `bot.js` (no more 409 churn), patches `mias/index.js` (reaction guarded, image-card falls back to text menu, boot log shows tt handler binding), clears stale `app-state-sync-*` snapshots (Bad MAC fix). Idempotent. |
| `mias/features/tiktok.js` | **overwrites** the existing file | Adds tiklydown + 2 cobalt instances as providers with 20s per-provider timeouts, so one dead/rate-limited provider can't blank the command anymore. Same exports — drop-in. |
| `package.json` | **overwrites** the existing file | Only change: `start` and `dev` scripts now run `fix_v26.cjs`. |

## Install

```bash
# in your local clone of precious125588/fantastic-waddle
cp fix_v26.cjs ./
cp package.json ./
cp tiktok.js mias/features/tiktok.js
git add -A && git commit -m "v26: fix telegram 409 war + tiktok silent failure" && git push
```

Railway redeploys automatically on push.

## ⚠️ THE STEP THAT ACTUALLY FIXES THE 409 LOOP

The code makes the bot survive the conflict, but the conflict itself exists
because **two Railway services/deployments are running this bot at once**
(same Telegram token, same WhatsApp session → also the WA `405 Conflict`
lines and the `Bad MAC` storm in your logs).

1. Railway dashboard → your project → find the **OLD service** (the "old one
   still there") → **Delete it** (or at minimum stop it).
2. Keep exactly **ONE** service. Settings → confirm the volume is mounted at
   `/app/nexstore` and `SESSION_DIR=/app/nexstore/pairing`.
3. Set `TELEGRAM_BOT_TOKEN` in **one place only**: Railway Variables **or**
   the admin panel — not both.
4. Redeploy.

## What a healthy boot looks like after this fix

```
[v26] PATCHED   bot.js
[v26] PATCHED   mias/index.js
[v26] Bad-MAC repair: cleared N stale app-state-sync-* snapshot(s)
[v26] hotfix pass complete
✅ [Telegram] Polling started.          ← exactly ONCE, no 409 wall after
[v26] tt handler bound: tiktok=ok tt=ok ttdl=ok
```

Then test in WhatsApp: `.tt <tiktok link>` → you get the image card (or, if
WhatsApp rejects the image, the same menu as plain text — never silence),
reply `1.3` → HD video.

If 409s still appear after deleting the old service: your token leaked into a
third deployment somewhere — revoke it with @BotFather (`/revoke`) and set the
new token.
